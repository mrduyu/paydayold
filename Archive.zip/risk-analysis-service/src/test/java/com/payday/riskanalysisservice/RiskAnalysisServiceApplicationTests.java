package com.payday.riskanalysisservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RiskAnalysisServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
