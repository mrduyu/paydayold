package com.payday.authenticationgservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthenticationgServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthenticationgServiceApplication.class, args);
	}


}
