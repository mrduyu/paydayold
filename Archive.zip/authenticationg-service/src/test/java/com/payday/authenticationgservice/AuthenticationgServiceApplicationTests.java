package com.payday.authenticationgservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationgServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
